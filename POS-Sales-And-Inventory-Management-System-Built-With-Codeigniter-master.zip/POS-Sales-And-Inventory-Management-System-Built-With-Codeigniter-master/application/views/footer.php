</div> 
</div>
</div>
<footer class="" style="clear: both;">
	<div class="container-fluid">
		<p>&copy; Copyright 2017 | All Rights Reserverd <br> This Website Is Designed And Developed By Alger Makiputin</p>
	</div>
</footer>
</body>
</html>