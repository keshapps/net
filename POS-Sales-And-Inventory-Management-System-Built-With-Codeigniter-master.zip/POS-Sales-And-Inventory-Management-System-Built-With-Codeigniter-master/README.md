# POS-Sales-And-Inventory-Management-System-Built-With-Codeigniter
Web Base POS Sales And Inventory System Built Using Codeigniter Framework

This Is The Login Page
![](images/1.PNG)
Their are 3 types of users.
1. Cashier
2. Clerk
3. Admin
If Cashier user will redirect to POS page, if clerk or admin will be redirect to inventory page.<br>
In this image admin is login.<br>
I missspelled logout for lagout here :( 
![](images/2.PNG)
This Is the Add New Item Form
![](images/3.PNG)
You can also view your daily/weekly/monthly/yearly sales. navigate through the navigation on the top of the table.
![](images/4.PNG)
Add Category Form, When you register and Item You will select a category of the item. so first you have to register it's category.
![](images/5.PNG)
Simple Account Registration form only getting few details. only admins can access this. when the user is clerk this panel will hide. the password is also hash before saving into the database.
![](images/6.PNG)
Now Lets try Logging In Cashier Type Account.
![](images/7.PNG)
Cashier Account Will redirect In the POS interface.
![](images/8.PNG)
The cashier will enter the name of the item in the item name field and it will autocomplete and the item info will display in the right side. 
![](images/9.PNG)
Payment 
![](images/10.PNG)
Displays the total amount, payment and change for the customer.
![](images/11.PNG)

